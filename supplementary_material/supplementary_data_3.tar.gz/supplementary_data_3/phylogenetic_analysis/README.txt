# supplementary_data_3: phylogenetic_analysis

## cluster_ids/
- file from basic KinFin run containing cluster IDs of "true" single-copy orthologue cluster  

## alignments/
- Alignments of proteins for each "true" single-copy orthologue clusters 

## tree/
- FcC_smatrix.fas: concatenated alignments used for phylogenetic analysis
- RAxML_bestTree.ml: Best ML tree from RAxML
- RAxML_bootstrap.bs: Result from RAxML bootstrapping analysis
- RAxML_bipartitions.final: Final tree
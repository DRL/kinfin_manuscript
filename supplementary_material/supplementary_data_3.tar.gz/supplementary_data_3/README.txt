# supplementary_data_3: Output files analyses

## kinfin.basic.kinfin_results
- Output files of basic KinFin analysis

## kinfin.advanced.kinfin_results
- Output files of advanced KinFin analysis

## kinfin.additional_analyses
- Output files of additional analysis performed on output files of advanced KinFin analysis

## phylogenetic_analysis
- input/output files of phylogenetic analysis


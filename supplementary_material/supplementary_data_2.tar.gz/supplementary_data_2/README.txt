# supplementary_data_2: Input files for advanced KinFin analysis

## kinfin.config.advanced.txt
- KinFin config file for advanced analysis

## kinfin.SequenceIDs.txt
- SequenceIDs.txt file from OrthoFinder analysis

## Orthogroups.I1_5.txt
- Result of protein clustering analysis using OrthoFinder

## kinfin.SpeciesIDs.txt
- SpeciesIDs.txt file from OrthoFinder analysis

## fastas/
- directory containing proteomes used in the OrthoFinder protein clustering analysis in FASTA format 

## kinfin.interproscan.tsv
- InterProScan output 

## kinfin.functional_annotation.txt
- InterProScan output converted to KinFin format using the script kinfin/scripts/iprs2table.py

## kinfin.tree.nwk
- Species tree in newick format
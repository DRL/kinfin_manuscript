# supplementary_data_1: Input files for basic KinFin analysis

## kinfin.config.basic
- KinFin config file for basic analysis

## Orthogroups.I1_5.txt
- Result of protein clustering analysis using OrthoFinder

## kinfin.SequenceIDs.txt
- SequenceIDs.txt file from OrthoFinder analysis
